# Credit Repair JS Pack (Pro)

A polished JavaScript bundle to add **eye‑catching, professional UX** to a credit repair website—complete with accessible components, smooth interactions, intake form validation, autosave, state selection, and realistic dispute timeline estimates.

## Files
- `core.js` — tiny utilities (qs/qsa, events, debounce, storage, focus‑trap)
- `ui.js` — sticky navbar, active link highlighter, smooth scroll, theme toggle, modal, toast, reveal‑on‑scroll
- `forms.js` — intake + contact validation, phone mask, email check, autosave (localStorage), character counts
- `timeline.js` — dispute timeline estimator (minor vs. moderate vs. serious issues)
- `states.js` — US states list + helper to render a `<select>` with smart defaults
- `init.js` — boot file that wires everything together (call once at the end of `body`)

## Quick Start
1. Put these files in `/js/` and load them (after your CSS), ideally just before `</body>`:
```html
<script src="js/core.js"></script>
<script src="js/ui.js"></script>
<script src="js/forms.js"></script>
<script src="js/states.js"></script>
<script src="js/timeline.js"></script>
<script src="js/init.js"></script>
```

2. Add these IDs/classes to your HTML (examples):

**Navbar + sections**
```html
<nav class="navbar container" id="navbar">
  <ul class="nav" id="navLinks">
    <li><a class="nav__link" href="#pricing">Pricing</a></li>
    <li><a class="nav__link" href="#intake">Intake</a></li>
    <li><a class="nav__link" href="#resources">Resources</a></li>
    <li><a class="btn btn--ghost" href="#contact">Contact</a></li>
  </ul>
  <button class="btn btn--ghost" id="themeToggle" aria-label="Toggle theme">Theme</button>
</nav>
```

**Intake form**
```html
<form id="intakeForm" class="form card">
  <div class="grid grid-2">
    <label>Full name
      <input class="input" id="fullName" name="name" required>
    </label>
    <label>Email
      <input class="input" id="email" name="email" type="email" required>
    </label>
  </div>
  <label>Phone
    <input class="input" id="phone" name="phone" placeholder="(555) 555-5555">
  </label>
  <label>State
    <select class="select" id="state"></select>
  </label>
  <label>Issue Type
    <select class="select" id="issueType" required>
      <option value="">Choose one…</option>
      <option value="minor">Minor (name/address/date of birth)</option>
      <option value="moderate">Moderate (not my account / inquiry)</option>
      <option value="serious">Serious (late pay / repo / bankruptcy)</option>
    </select>
  </label>
  <label>Describe the issue
    <textarea class="textarea" id="issueDetails" rows="5" maxlength="1200" placeholder="Tell us what’s wrong…"></textarea>
    <div class="muted" id="issueCount">0 / 1200</div>
  </label>
  <div class="button-row">
    <button class="btn btn--gold btn--lg" type="submit">Submit Audit Request</button>
    <button class="btn btn--outline" type="button" id="clearIntake">Clear</button>
  </div>
</form>
```

**Timeline Estimator**
```html
<div class="card" id="timelineCard">
  <h3 class="h3">Estimated Timeline</h3>
  <p class="muted" id="timelineText">Select an issue type to estimate.</p>
</div>
```

**Modal (for toasts you don’t need markup)**
```html
<div id="modal" class="modal" role="dialog" aria-modal="true" aria-hidden="true">
  <div class="modal__dialog" role="document">
    <h3 class="h3" id="modalTitle">Thanks!</h3>
    <p class="muted" id="modalBody">We’ll reach out soon.</p>
    <div class="button-row">
      <button class="btn btn--gold" id="modalClose">Close</button>
    </div>
  </div>
</div>
```

3. Call the initializer (already done if you include `init.js`):
```html
<script>window.Stayton.init();</script>
```

## Notes
- All features are **progressive**: they enhance but won’t break without JS.
- Uses `localStorage` keys prefixed with `ccr:` to avoid collisions.
- The timeline estimator reflects your documented ranges.
