/* ===== core.js ===== */
window.$ = (sel, ctx=document) => ctx.querySelector(sel);
window.$$ = (sel, ctx=document) => Array.from(ctx.querySelectorAll(sel));

const on = (el, ev, fn, opts) => el && el.addEventListener(ev, fn, opts);
const off = (el, ev, fn, opts) => el && el.removeEventListener(ev, fn, opts);

const debounce = (fn, wait=200) => {
  let t; return (...args) => {
    clearTimeout(t); t = setTimeout(() => fn.apply(null, args), wait);
  };
};

const store = {
  set(key, val){ try{ localStorage.setItem(key, JSON.stringify(val)); }catch(e){} },
  get(key, fallback=null){ try{ const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }catch(e){ return fallback; } },
  del(key){ try{ localStorage.removeItem(key); }catch(e){} }
};

// Focus trap for modals
const trapFocus = (container) => {
  if(!container) return () => {};
  const focusables = $$('a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])', container).filter(el => !el.hasAttribute('disabled'));
  let first = focusables[0], last = focusables[focusables.length - 1];
  const handle = (e) => {
    if(e.key !== 'Tab') return;
    if(e.shiftKey && document.activeElement === first){ e.preventDefault(); last.focus(); }
    else if(!e.shiftKey && document.activeElement === last){ e.preventDefault(); first.focus(); }
  };
  on(container, 'keydown', handle);
  return () => off(container, 'keydown', handle);
};

window.Core = { on, off, debounce, store, trapFocus };
