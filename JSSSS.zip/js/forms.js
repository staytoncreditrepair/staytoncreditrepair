/* ===== forms.js ===== */
(function(){
  const { on, debounce, store } = window.Core;
  const form = $('#intakeForm');
  const phone = $('#phone');
  const email = $('#email');
  const nameInput = $('#fullName');
  const details = $('#issueDetails');
  const count = $('#issueCount');
  const clearBtn = $('#clearIntake');

  // Character counter
  if(details && count){
    const updateCount = () => count.textContent = `${details.value.length} / ${details.maxLength || 1200}`;
    on(details, 'input', updateCount); updateCount();
  }

  // Phone mask (basic)
  const maskPhone = (v) => {
    const d = (v || '').replace(/\D/g, '').slice(0,10);
    const p1 = d.slice(0,3), p2 = d.slice(3,6), p3 = d.slice(6,10);
    if(d.length > 6) return `(${p1}) ${p2}-${p3}`;
    if(d.length > 3) return `(${p1}) ${p2}`;
    if(d.length > 0) return `(${p1}`;
    return '';
  };
  if(phone){
    on(phone, 'input', () => { const p = phone.selectionStart; phone.value = maskPhone(phone.value); phone.selectionStart = phone.selectionEnd = p; });
  }

  // Email quick validation
  const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v || '');

  // Autosave
  const KEY = 'ccr:intakeDraft';
  const saveDraft = debounce(() => {
    const data = {
      name: nameInput?.value || '',
      email: email?.value || '',
      phone: phone?.value || '',
      state: $('#state')?.value || '',
      issueType: $('#issueType')?.value || '',
      issueDetails: details?.value || ''
    };
    store.set(KEY, data);
    window.toast && toast('Draft saved');
  }, 600);

  [nameInput, email, phone, $('#state'), $('#issueType'), details].forEach(el => el && on(el, 'input', saveDraft));

  // Restore draft
  const draft = store.get(KEY, null);
  if(draft){
    if(nameInput) nameInput.value = draft.name;
    if(email) email.value = draft.email;
    if(phone) phone.value = draft.phone;
    if($('#state')) $('#state').value = draft.state;
    if($('#issueType')) $('#issueType').value = draft.issueType;
    if(details) details.value = draft.issueDetails;
  }

  // Clear form
  on(clearBtn, 'click', () => {
    if(!form) return;
    form.reset(); store.del(KEY);
    toast('Cleared');
    $('#timelineText') && ($('#timelineText').textContent = 'Select an issue type to estimate.');
  });

  // Submit (front-end only)
  on(form, 'submit', (e) => {
    e.preventDefault();
    const valid = (nameInput?.value.trim().length >= 2) && isEmail(email?.value);
    if(!valid){ toast('Please enter a valid name and email.'); return; }
    // Simulate success
    store.del(KEY);
    UI.openModal('Thanks!', 'We got your request and will reach out shortly.');
  });
})();
