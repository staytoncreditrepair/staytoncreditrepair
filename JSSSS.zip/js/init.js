/* ===== init.js ===== */
window.Stayton = window.Stayton || {};
window.Stayton.init = function(){
  // Already loaded by script tags. Put bootstrapping here if needed.
  // Example toast and reveal:
  setTimeout(()=> window.toast && toast('Welcome to Cory’s Credit Repair'), 500);
};
// Auto-init if running inline
document.addEventListener('DOMContentLoaded', ()=> window.Stayton.init());
