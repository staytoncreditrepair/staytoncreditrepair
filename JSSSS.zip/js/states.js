/* ===== states.js ===== */
(function(){
  const states = [
    {v:'AL',n:'Alabama'},{v:'AK',n:'Alaska'},{v:'AZ',n:'Arizona'},{v:'AR',n:'Arkansas'},
    {v:'CA',n:'California'},{v:'CO',n:'Colorado'},{v:'CT',n:'Connecticut'},{v:'DE',n:'Delaware'},
    {v:'FL',n:'Florida'},{v:'GA',n:'Georgia'},{v:'HI',n:'Hawaii'},{v:'ID',n:'Idaho'},
    {v:'IL',n:'Illinois'},{v:'IN',n:'Indiana'},{v:'IA',n:'Iowa'},{v:'KS',n:'Kansas'},
    {v:'KY',n:'Kentucky'},{v:'LA',n:'Louisiana'},{v:'ME',n:'Maine'},{v:'MD',n:'Maryland'},
    {v:'MA',n:'Massachusetts'},{v:'MI',n:'Michigan'},{v:'MN',n:'Minnesota'},{v:'MS',n:'Mississippi'},
    {v:'MO',n:'Missouri'},{v:'MT',n:'Montana'},{v:'NE',n:'Nebraska'},{v:'NV',n:'Nevada'},
    {v:'NH',n:'New Hampshire'},{v:'NJ',n:'New Jersey'},{v:'NM',n:'New Mexico'},{v:'NY',n:'New York'},
    {v:'NC',n:'North Carolina'},{v:'ND',n:'North Dakota'},{v:'OH',n:'Ohio'},{v:'OK',n:'Oklahoma'},
    {v:'OR',n:'Oregon'},{v:'PA',n:'Pennsylvania'},{v:'RI',n:'Rhode Island'},{v:'SC',n:'South Carolina'},
    {v:'SD',n:'South Dakota'},{v:'TN',n:'Tennessee'},{v:'TX',n:'Texas'},{v:'UT',n:'Utah'},
    {v:'VT',n:'Vermont'},{v:'VA',n:'Virginia'},{v:'WA',n:'Washington'},{v:'WV',n:'West Virginia'},
    {v:'WI',n:'Wisconsin'},{v:'WY',n:'Wyoming'}
  ];

  const sel = document.getElementById('state');
  if(!sel) return;
  sel.innerHTML = '<option value="">Select your state…</option>' + states.map(s => `<option value="${s.v}">${s.n}</option>`).join('');
  // Default Texas if empty (your business base)
  if(!sel.value) sel.value = 'TX';
})();
