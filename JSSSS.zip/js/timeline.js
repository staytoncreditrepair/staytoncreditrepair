/* ===== timeline.js ===== */
(function(){
  const issueSel = $('#issueType');
  const out = $('#timelineText');
  if(!issueSel || !out) return;

  const ranges = {
    minor:  { label: 'Minor corrections',        daysMin: 30, daysMax: 40,  note:'Name, address, DOB fixes' },
    moderate:{ label: 'Moderate disputes',        daysMin: 30, daysMax: 90,  note:'Accounts not yours / inquiries' },
    serious:{ label: 'Serious derogatories',      daysMin: 180, daysMax: 365, note:'Late pays, repos, bankruptcy' }
  };

  const toHuman = (days) => {
    if(days < 60) return `${days} days`;
    const months = Math.round(days/30);
    return `${months} month${months>1?'s':''}`;
  };

  const update = () => {
    const v = issueSel.value;
    if(!v){ out.textContent = 'Select an issue type to estimate.'; return; }
    const r = ranges[v];
    const msg = `${r.label}: about ${toHuman(r.daysMin)} to ${toHuman(r.daysMax)} (${r.note}).`;
    out.textContent = msg;
  };

  issueSel.addEventListener('change', update);
  update();
})();
