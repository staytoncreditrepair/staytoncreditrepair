/* ===== ui.js ===== */
(function(){
  const { on, debounce, trapFocus } = window.Core;

  // Sticky navbar + shadow
  const navbar = $('#navbar') || $('.navbar');
  const setSticky = () => {
    if(!navbar) return;
    if(window.scrollY > 8) navbar.style.boxShadow = 'var(--shadow-sm)';
    else navbar.style.boxShadow = 'none';
  };
  on(document, 'scroll', debounce(setSticky, 10));
  setSticky();

  // Smooth scroll for in-page links
  $$('.nav__link[href^="#"]').forEach(a => {
    on(a, 'click', (e) => {
      const id = a.getAttribute('href'); if(!id) return;
      const target = document.querySelector(id);
      if(target){ e.preventDefault(); target.scrollIntoView({behavior:'smooth', block:'start'}); }
    });
  });

  // Active link sync on scroll
  const sections = $$('.section[id]');
  const links = $$('.nav__link');
  const syncActive = () => {
    let activeId = null;
    sections.forEach(sec => {
      const r = sec.getBoundingClientRect();
      if(r.top <= innerHeight*0.35) activeId = '#' + sec.id;
    });
    links.forEach(l => l.classList.toggle('is-active', l.getAttribute('href') === activeId));
  };
  on(document, 'scroll', debounce(syncActive, 50)); syncActive();

  // Theme toggle (light/dark within brand palette)
  const toggle = $('#themeToggle');
  const THEME_KEY = 'ccr:theme';
  const applyTheme = (t) => document.documentElement.dataset.theme = t;
  const saved = Core.store.get(THEME_KEY, 'dark');
  applyTheme(saved);
  on(toggle, 'click', () => {
    const next = (document.documentElement.dataset.theme === 'dark') ? 'light' : 'dark';
    Core.store.set(THEME_KEY, next); applyTheme(next);
  });

  // Reveal on scroll (fade-in)
  const observer = new IntersectionObserver((entries)=>{
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add('fade-in');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  $$('.card,.pricing,.section__title,.btn').forEach(el => observer.observe(el));

  // Toast API
  const toastHost = document.createElement('div');
  toastHost.style.position='fixed'; toastHost.style.inset='auto 1rem 1rem auto'; toastHost.style.zIndex='2000';
  document.body.appendChild(toastHost);
  window.toast = (msg, timeout=3200) => {
    const el = document.createElement('div');
    el.className = 'badge badge--gold shadow'; el.style.marginTop = '.5rem';
    el.textContent = msg;
    toastHost.appendChild(el);
    setTimeout(()=> el.remove(), timeout);
  };

  // Modal API
  const modal = $('#modal');
  let releaseTrap = () => {};
  const openModal = (title, body) => {
    if(!modal) return;
    if(title) $('#modalTitle').textContent = title;
    if(body) $('#modalBody').textContent = body;
    modal.classList.add('is-open');
    releaseTrap = trapFocus(modal);
    $('#modalClose')?.focus();
  };
  const closeModal = () => {
    if(!modal) return;
    modal.classList.remove('is-open');
    releaseTrap && releaseTrap();
  };
  on($('#modalClose'), 'click', closeModal);
  on(modal, 'click', (e)=>{ if(e.target === modal) closeModal(); });
  on(document, 'keydown', (e)=>{ if(e.key === 'Escape' && modal?.classList.contains('is-open')) closeModal(); });

  window.UI = { openModal, closeModal, toast };
})();
