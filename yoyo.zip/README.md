# Credit Repair CSS Pack (Navy · Gold · White)

This pack includes production-ready CSS for a sleek, professional **credit repair** website with bold, trustworthy vibes.

## Files
- `reset.css` — Modern CSS reset + sensible defaults
- `theme.css` — Color variables, typography, layout helpers
- `components.css` — Buttons, navbars, hero, cards, pricing, forms, tables, badges, alerts, modals, footer
- `utilities.css` — Quick utility classes (spacing, flex, grid, shadows, borders, text)
- `animations.css` — Subtle motion for hover/focus/entrance
- `print.css` — Print-friendly styling for agreements, invoices, and letters

## Quick Start
1. In your HTML `<head>`, include the styles in this order:
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;900&family=DM+Serif+Display:ital,wght@0,400;1,400&display=swap" rel="stylesheet">

<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/theme.css">
<link rel="stylesheet" href="css/components.css">
<link rel="stylesheet" href="css/utilities.css">
<link rel="stylesheet" href="css/animations.css" media="(prefers-reduced-motion: no-preference)">
<link rel="stylesheet" href="css/print.css" media="print">
```

2. Add the `brand` helper to your `<body>` to turn on brand theming:
```html
<body class="brand">
  <!-- your site -->
</body>
```

3. Example hero + CTA in your HTML:
```html
<header class="hero hero--dark">
  <nav class="navbar container">
    <a class="logo" href="/">Cory's Credit Repair</a>
    <ul class="nav">
      <li><a href="#pricing" class="nav__link">Pricing</a></li>
      <li><a href="#intake" class="nav__link">Intake</a></li>
      <li><a href="#resources" class="nav__link">Resources</a></li>
      <li><a href="#contact" class="btn btn--ghost">Contact</a></li>
    </ul>
  </nav>
  <div class="container hero__content">
    <h1 class="display">World’s Best Credit Repair</h1>
    <p class="lead">Transparent pricing. Real timelines. No fluff—just results.</p>
    <div class="button-row">
      <a href="#intake" class="btn btn--gold btn--lg">Start Your Free Audit</a>
      <a href="#pricing" class="btn btn--outline btn--lg">See Pricing</a>
    </div>
  </div>
</header>
```

4. Pricing grid sample:
```html
<section id="pricing" class="section container">
  <h2 class="h2 section__title">Simple, honest pricing</h2>
  <div class="grid grid-3 gap-lg">
    <article class="card pricing">
      <h3 class="pricing__title">Kickoff Session</h3>
      <p class="pricing__price">$150</p>
      <p class="muted">Sit down together and review your report.</p>
      <a class="btn btn--gold btn--block" href="#book">Book Now</a>
    </article>
    <article class="card pricing card--accent">
      <h3 class="pricing__title">Monthly Plan</h3>
      <p class="pricing__price">$99<span class="pricing__price--sub">/mo</span></p>
      <p class="muted">First 15 inquiries free; $10 per removal after.</p>
      <a class="btn btn--dark btn--block" href="#subscribe">Get Started</a>
    </article>
    <article class="card pricing">
      <h3 class="pricing__title">Identity Theft Package</h3>
      <p class="pricing__price">Custom</p>
      <p class="muted">Tailored letters, filings, and timelines.</p>
      <a class="btn btn--outline btn--block" href="#contact">Talk to Us</a>
    </article>
  </div>
</section>
```

## Notes
- Colors, spacing, and shadows are tuned for **trust + clarity**.
- Navy (#0B1B38) and Gold (#D4AF37) are the brand anchors; white and deep charcoal support contrast.
- Use the utilities to move fast without writing custom CSS every time.
- Forms + tables are optimized for compliance docs and printable packets.
- You can tweak anything in `:root` inside `theme.css` to quickly rebrand.
